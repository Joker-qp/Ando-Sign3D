# holographic-display
A transparent 360° holographic display

This is a dump of the source files of the holographic display I have built on my YouTube Channel: https://www.youtube.com/watch?v=PRfdHhz7M4Q

This repo is intended to share all the design files I have prepared while building this project. I did not prepare a detailed guide since this is a very early prototype with a lot of flaws. When I design a more robust version I will definitely prepare a detailed guide to build one.
